<?php


/**
* 
*/
class CheckoutModel extends CI_Model
{
	
	
	public function checkout() {

		$info = $this->input->post('form_data');
		$this->load->library('form_validation');

		$output = array('status'=>'false','fname'=>'','lname'=>'','email'=>'','address'=>'','address2'=>'','city'=>'','country'=>'','pincode'=>'','phone'=>'','order_note'=>'','payment_method'=>'');

		if ($this->form_validation->run('checkout_form_validation')==FALSE) {
			

			$output['status']     = 'false';
			$output["fname"]          = form_error('fname');
			$output["lname"]          = form_error('lname');
			$output["email"]          = form_error('email');
			$output["address"]        = form_error('address');
			$output["address2"]       = form_error('address2');
			$output["city"]           = form_error('city');
			$output["country "]       = form_error('country');
			$output["pincode"]        = form_error('pincode');
			$output["phone"]          = form_error('phone');
			$output["order_note"]     = form_error('order_note');
			$output["payment_method"] = form_error('payment_method');
			

		} else {

			$info['order_status'] = 'placed';
			$info['payment_status'] = 'pending';
			if ($this->session->userdata('is_logged_in')) {
				$info['user_id']  = $this->session->userdata('user_id');
			}

			if ($this->cart->total_items()>0) {
				
				$this->db->insert('order_product',$info);

				if ($this->db->affected_rows()) {

						$output['status'] = 'true';

				}

			}



		}

		return $output;

	}

}