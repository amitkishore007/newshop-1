<?php $this->load->view('admin_includes/header'); ?>
<?php $this->load->view($main_content); ?>
<?php $this->load->view('admin_includes/footer'); ?>
