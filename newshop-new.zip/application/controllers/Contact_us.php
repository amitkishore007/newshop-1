<?php 
defined('BASEPATH') OR exit('No direct script access allowed');



/**
* 
*/
class Contact_us extends CI_Controller
{
	
	

	public function __construct() {

		parent :: __construct();

	}

	public function index() {

	}

	public function create() {

	}

	public function edit() {


	}


	public function store() {

		
	}

	public function delete() {


	}


}